package com.HUANSHI.HQW;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;

class gridviewlist {
    int id;
    String name;
    Drawable logo;
    String huazhi;
}
