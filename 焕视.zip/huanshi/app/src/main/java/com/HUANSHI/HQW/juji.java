package com.HUANSHI.HQW;

class juji {
    String jujiname;
    String href;
}
