package com.HUANSHI.HQW;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;

class hqwlist {
    public int id;
    public String name;
    public String jiesao;
    public Drawable biglogo;
}
